<?php
/*	Author: Ferdi Smit (smit@xs4all.nl)
	Thanks to Paul Johnston for the MD5 javascript lib (http://pajhome.org.uk/crypt/md5/index.html)
	Last Modification:	August 11th 2001
*/
	$passw = 'foobar';

	session_start();
	session_register('validuser');
	session_register('rndval');

	function reloadself() {
		print('<SCRIPT LANGUAGE="Javascript">this.location = document.location;</SCRIPT>');
	}

	if (!isSet($HTTP_SESSION_VARS['validuser']) || !$HTTP_SESSION_VARS['validuser']) {
		// password transmitted, check if correct
		if (isSet($HTTP_POST_VARS['postpass']) && isSet($HTTP_POST_VARS['rndval']) && isSet($HTTP_SESSION_VARS['rndval'])) {
			if ($HTTP_POST_VARS['rndval'] == md5($HTTP_SESSION_VARS['rndval']) && $HTTP_POST_VARS['postpass'] == md5($passw)) {
				$HTTP_SESSION_VARS['validuser'] = true;
				reloadself();	// to stop the nagging about expired pages...^__^
			}
			// wrong password or challenge
			else {
				session_destroy();
				reloadself();
				die('wrong password');
			}
		}
		// display the login form
		else { 
			mt_srand ((double) microtime() * 1000000); 
			$HTTP_SESSION_VARS['rndval'] = mt_rand();
		?>
			<HTML>
			<HEAD>
			<script language="JavaScript" src="md5.js"></script>
			<script language="JavaScript">
				function onformsubmit() {
					var f = document.forms[0];
					if (!f) {	
						alert('incompatible browser');
						return false;
					}
					f.postpass.value = calcMD5(f.postpass.value);
					f.rndval.value = calcMD5(f.rndval.value);
					return true;
				}
			</SCRIPT>
			</HEAD>
			<BODY><CENTER>
			<TABLE height="75%"><TR><TD valign="center"><B>Password:</B><br>
			<FORM onSubmit="return onformsubmit();" NAME="logon" METHOD="POST" ACTION="<?php print($HTTP_SERVER_VARS['PHP_SELF']);?>">
			<INPUT TYPE="PASSWORD" NAME="postpass">
			<INPUT TYPE="HIDDEN" NAME="rndval" VALUE="<?php print($HTTP_SESSION_VARS['rndval']);?>">
			<INPUT TYPE="Submit" VALUE="Logon">
			</FORM></TD></TR></TABLE>
			</CENTER>
			</BODY></HTML>
		<?php 
			die();
		}
	}
	// validuser set to true, user already logged on, continue.
	unset($passw);
	session_unregister('rndval');
?>