<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Client Login</title>
</head>

<body>

<?php
if (!@mysql_pconnect() || !mysql_select_db("authentication"))
	echo mysql_error();
else {
?>
<script src="md5.js"></script>
<script language="JavaScript"><!--
function login(f) {
	f['md5'].value = hex_hmac_md5(f['id'].value, f['password'].value);
	f['password'].value = '';
	return true;
}
//--></script>
<noscript>
<p>Enable JavaScript for safe login.</p>
</noscript>
<form action="server.php" method="post" onSubmit="return login(this);">
<?php
mysql_query("INSERT INTO logins (id, used) VALUES (NULL, 0)");
?>
<input type="hidden" name="id" value="<?php echo mysql_insert_id(); ?>">
<input type="hidden" name="md5" value="">
Password: <input type="password" name="password">
<input type="submit" value="Login">
</form>
<?php
}
?>

</body>
</html>
