CREATE DATABASE authentication;
USE authentication;

CREATE TABLE logins (
	id int NOT NULL AUTO_INCREMENT,
	used bool NOT NULL,
	PRIMARY KEY (id)
);
