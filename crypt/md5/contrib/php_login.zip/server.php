<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Server Authentication</title>
</head>

<body>

<?php
$password = "password";

function hmac_md5($key, $data) {
	if (extension_loaded("mhash"))
		return bin2hex(mhash(MHASH_MD5, $data, $key));
	
	// RFC 2104 HMAC implementation for php. Hacked by Lance Rushing
	$b = 64; // byte length for md5
	if (strlen($key) > $b)
		$key = pack("H*", md5($key));
	$key = str_pad($key, $b, chr(0x00));
	$ipad = str_pad("", $b, chr(0x36));
	$opad = str_pad("", $b, chr(0x5c));
	$k_ipad = $key ^ $ipad ;
	$k_opad = $key ^ $opad;
	
	return md5($k_opad . pack("H*", md5($k_ipad . $data)));
}

if (!isset($_REQUEST["id"]))
	echo "Use Client Login first.";
elseif (!@mysql_pconnect() || !mysql_select_db("authentication"))
	echo mysql_error();
else {
	mysql_query("UPDATE logins SET used = 1 WHERE id = '$_REQUEST[id]'");
	if (!mysql_affected_rows())
		echo "Login ID was already used.";
	elseif ($_REQUEST["md5"]) {
		// JavaScript on client
		if (hmac_md5($_REQUEST["id"], $password) == $_REQUEST["md5"])
			echo "Safe login with right password.";
		else
			echo "Safe login with bad password.";
	}
	elseif ($password == $_REQUEST["password"])
		echo "Unsafe login with right password.";
	else
		echo "Unsafe login with bad password.";
}
?>
<p><a href="client.php">Client Login</a></p>

</body>
</html>
