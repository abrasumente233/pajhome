<?
if(isset($_GET[session_name()])) {
	session_id($_GET[session_name()]);
}
// note that this is not an else if. this
// means that the order of the current session
// id will be as follows:
// 1. the value of a post attribute
// 2. the value of a get attribute
// 3. anything that was known as session_id

if(isset($_POST[session_name()])) {
	session_id($_POST[session_name()]);
}
session_start();

function session_input() {
	if(isset($_COOKIE[session_name()]))
		return "";
	// else
	return '<INPUT TYPE="hidden" NAME="' 
		   . session_name() 
		   . '" VALUE="' 
		   . session_id() 
		   . '">';
}

function sessionise($page) {
	if(isset($_COOKIE[session_name()]))
		return $page;
	// else ... session id is not in a cookie, add it to the URL

	if(strpos($page, session_name()) === false){
		// session id has not been added, do it now

		// do we have a ? in the URL already?
		if(strrpos($page, "?") === false) {
//			echo "no ? in $page";
			$connector = "?";
		} else {
//			echo "got a ? in $page";
			$connector = "&";
		}

		$page = $page . $connector . session_name() . "=" . session_id();
//		echo "returning ".$page;
		return $page;
	}
	else
		return $page;
}
?>