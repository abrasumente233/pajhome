<?php

function ExecuteQuery($query) {
	$database="";
	$host="localhost";
	$db_user="";
	$db_pass="";

	$linkID = mysql_connect($host, $db_user, $db_pass)
		or die("Verbinding met database is mislukt: " . mysql_error());
	mysql_select_db($database, $linkID)
		or die("Kon database niet selecteren: " . mysql_error());
	$result = mysql_query($query, $linkID)
		or die("Invalid query: " . $query ." --&gt; ". mysql_error());
	return $result;
}

function GetHeaders($result) {
	$headers = array();

	for($i =0; $i < mysql_num_fields($result); $i++) {
	    $meta = mysql_fetch_field($result, $i);
	    $meta or die("No header information available");
	    $headers[] = $meta->name;
	}
	return $headers;
}

?>

