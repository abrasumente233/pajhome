<?php
$GLOBALS['notAllowed'] = "U heeft niet de juiste rechten om deze pagina te bekijken";
$GLOBALS['wrongUserPassword'] = "Onbekende gebruikersnaam/wachtwoord combinatie";
$GLOBALS['sessionHijack'] = "Uw sessie hoort bij een andere computer. Uw computer is ".$_SERVER['REMOTE_ADDR'];
// $GLOBALS[] = "";
?>