<?php //protectme.inc
	
	require_once($_SERVER['DOCUMENT_ROOT'].'/include/text/protectme.text.inc.php');
	/**
	 * This function checks if the current user is logged in with a specific
	 * role. If this user is not logged in correctly, show login dialog and exit
	 * otherwise just continue.
	 * If $role === "" just check if the user is logged in.
	 */
	function requireUserInRole($role) {	
		$loginPageURL = $_SERVER['DOCUMENT_ROOT'].'/sec/login.php';
		// There are three options:
		// * The current user has already logged in. The roles are in the session, look
		//   to see if the role needed is in that array. If not, show login page.
		// * This is a login request. Try to log in the user. If this doesn't succeed 
		//   show the login page.
		// * Nothing know of the user. Just show the login page.
		// 
		// In all these choices, requiring the login.php and exit() means there is nothing
		// shown after the login page. return means continue with the current page.
		// I suppose I could put the exit() in login.php, but this way it is clearer that 
		// everything will stop afterwards (I think).
		
		if(isset($_SESSION['roles'])) {
			// check to see if the IP address is correct
			if($_SERVER['REMOTE_ADDR'] !== $_SESSION['ip']) {
				$_POST['reason'] = $GLOBALS['sessionHijack'];
				require_once($loginPageURL);
				exit();
			}
			
			// check to see if the role is in the roles array.
			
			// if the role is empty, we're already OK, 
			// since the roles isset in the session, the
			// current user must have at least one role
			if(!isset($role) || $role === "")
				return;
				
			// else try to find the current role in roles
			if(array_search($role, $_SESSION['roles']) === false) {
				// role was not found. prompt proper login
				$_POST['reason'] = $GLOBALS['notAllowed']; 
				require_once($loginPageURL);
				exit();
			} else {
				return;
			}
		} else if(isset($_POST['password']) && isset($_POST['user'])) {
			// take user and password from POST request
			// NB require_once POST for login
			require_once($_SERVER['DOCUMENT_ROOT'].'/sec/login.inc.php');
			if(login($_POST['user'], $_POST['password'])) {
				return;
			} else {
				$_POST['reason'] = $GLOBALS['wrongUserPassword']; 
				require_once($loginPageURL);
				exit();
			}
		} else {
			// no user known, show login page
			require_once($loginPageURL);
			exit();
		}
	}
	
?>