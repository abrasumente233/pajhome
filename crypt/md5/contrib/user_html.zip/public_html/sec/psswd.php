<?php
	require_once($_SERVER['DOCUMENT_ROOT']."/include/session.inc.php");
	require_once($_SERVER['DOCUMENT_ROOT']."/sec/login.inc.php");
	require_once($_SERVER['DOCUMENT_ROOT']."/sec/rijndael.inc.php");
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
<TITLE>password change results</TITLE>
<META NAME="Generator" CONTENT="TextPad 4.6">
<META NAME="Author" CONTENT="Friso Vrolijken">
<?php
	$loggedIn = false;
	$user = $_REQUEST['user'];
	if(login($user, $_REQUEST['encoldpass'])) {
		$newpwenc = hexToByteArray($_REQUEST['encnwpass']);

		$query = "select distinct(wachtwoord) from login where gebruiker='$user'";
		$result = executeQuery($query);
		unset($aKey);
		if($row = mysql_fetch_row($result)) {
			$aKey = $row[0];
		}
		$newpw = byteArrayToString(rijndaelDecrypt($newpwenc, formatPlaintext($aKey), 'ECB'));
		
		$loggedIn = true;
	} else {
		$loggedIn = false;
	}
?>
</HEAD>

<BODY>
<? if($loggedIn) { ?>
Het wachtwoord is gewijzigd
<? } else { ?>
Het wachtwoord is niet gewijzigd!<BR>
(oude wachtwoord incorrect?)
<? } ?>

</BODY>
</HTML>
