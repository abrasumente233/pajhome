<?php 
	require_once($_SERVER['DOCUMENT_ROOT']."/include/session.inc.php");

	function randString() {
		$result = "";
		$num = rand(4,8);
		for($i = 0; $i < $num; $i++) {
			$result = $result. base_convert(rand(0, 36), 10, 36);
		}
		return $result;
	}

	// if we need to login, we need a random variable
	$_SESSION['randString'] = randString();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
<?php
	if(isset($_SESSION['user'])) {
		$user = $_SESSION['user'];
	} else {
		$user = "";
	}
?>

<TITLE>change password</TITLE>
<META NAME="Generator" CONTENT="TextPad 4.6">
<META NAME="Author" CONTENT="Friso Vrolijken">
<SCRIPT SRC="sha1.inc.js"></SCRIPT> <!-- for random function --> 
<SCRIPT SRC="rijndael.inc.js"></SCRIPT>
<SCRIPT SRC="md5.inc.js"></SCRIPT>
<SCRIPT>
	// this function is basically a copy of preSubmit()
	// in login.php
	function setOldEncPW() {
		var pw = hex_md5(document.dummy.oldpassword.value);

		if(document.dummy.randString.value) {
			pw = pw + document.dummy.randString.value;
		} else {
			if(!confirm ("no random string set. do you want to continue?"))
				return false;
		}
		document.pswd.encoldpass.value = hex_md5(pw);
		return true;
	}

	function changePassword() {
		if(document.dummy.newpassword1.value != document.dummy.newpassword2.value) {
			alert("new password 1 and new password 2 are not identical. try again.");
			return;
		}
		// else
		
		// use old password to encrypt the new one. the old password will be 
		// stored in the database as md5 hash of what the user enteres, so 
		// also use that here.
		var aKey	= hex_md5(document.dummy.oldpassword.value);
		var aValue	= hex_md5(document.dummy.newpassword1.value);

		var hexEncNewPW = byteArrayToHex(
							rijndaelEncrypt(aValue, formatPlaintext(aKey), 'ECB')
						  );
	
		document.pswd.user.value = document.dummy.user.value;
		document.pswd.encnwpass.value = hexEncNewPW;
		
		// make sure we can check if the correct user is trying this
		setOldEncPW();
		
		document.pswd.submit();
	}
</SCRIPT>
</HEAD>

<BODY>

<FORM NAME="dummy" ACTION="javascript:changePassword()">
<INPUT TYPE="hidden" NAME="randString" VALUE="<?= $_SESSION['randString'] ?>">
<TABLE>
<TR>
	<TD> login name </TD>
	<TD> <input type="text" name="user" value="<?= $user ?>"> </TD>
</TR>
<TR>
	<TD> old password </TD>
	<TD> <input type="password" name="oldpassword"> </TD>
</TR>
<TR>
	<TD> new password </TD>
	<TD> <input type="password" name="newpassword1"> </TD>
</TR>
<TR>
	<TD> new password (control)</TD>
	<TD> <input type="password" name="newpassword2"> </TD>
</TR>
<TR>
	<TD COLSPAN="2">
		<INPUT TYPE="submit" value="doehet">
	</TD>
</TR>
</TABLE>
</FORM>

<FORM NAME="pswd" ACTION="psswd.php" METHOD="post">
<!--FORM NAME="pswd" ACTION="" METHOD="get"-->
	<INPUT TYPE="hidden" NAME="user">
	<INPUT TYPE="hidden" NAME="encnwpass">
	<INPUT TYPE="hidden" NAME="encoldpass">	
	<?= session_input(); ?>
</FORM>

</BODY>
</HTML>
