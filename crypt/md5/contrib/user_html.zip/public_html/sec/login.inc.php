<?
// NB. session must be started before this happens

require_once($_SERVER['DOCUMENT_ROOT']."/include/dbhelpers.inc.php");

function Login($user, $password) {
	if (!get_magic_quotes_gpc()) 
		$user = addslashes($user);
	
	// every user should have exactly one password
	// find it and compare to our parameter
	$query = "select distinct(wachtwoord) from login where gebruiker='$user'";
	$result = executeQuery($query);
	unset($dbPassword);
	while($row = mysql_fetch_row($result)) {
		if(isset($dbPassword))
			die("$user heeft meerdere wachtwoorden");
		$dbPassword = $row[0];
	}
	
	// check if password is correct
	// else just return
	$dbPassword = $dbPassword . $_SESSION['randString'];
	if(md5($dbPassword) !== $password)
		return false;
	
	
	// password is correct, select roles
	$query = "select rol from login where gebruiker='$user'";
	$result = executeQuery($query);

	$roles = array();
	while($row = mysql_fetch_row($result)) {
		$roles[] = $row[0];
	}

	if(count($roles) > 0) {
		$_SESSION['roles'] = $roles;
		$_SESSION['user'] = $user;	// might come in usefull
		// as a paranoia messure, store the IP address as well
		// now session hijacking will become more difficult
		$_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
		return true;
	} else {
		return false;
	}
}

?>