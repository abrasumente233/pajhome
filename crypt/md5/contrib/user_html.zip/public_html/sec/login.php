<?php 
	require_once($_SERVER['DOCUMENT_ROOT']."/include/session.inc.php");

	function randString() {
		$result = "";
		$num = rand(4,8);
		for($i = 0; $i < $num; $i++) {
			$result = $result. base_convert(rand(0, 36), 10, 36);
		}
		return $result;
	}

	// if we need to login, we need a random variable
	$_SESSION['randString'] = randString();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
	<TITLE>Login page</TITLE>
	<META NAME="Generator" CONTENT="TextPad 4.6">
	<META NAME="Author" CONTENT="Friso Vrolijken">
	<SCRIPT SRC="\sec\md5.inc.js"></SCRIPT>
	<SCRIPT>
	function preSubmit() {
		var pw = hex_md5(document.form.user_password.value);
		document.form.user_password.value="";
//		alert(pw);
		if(document.form.randString.value) {
			pw = pw + document.form.randString.value;
		} else {
			if(!confirm ("no random string set. do you want to continue?"))
				return false;
		}
		document.form.password.value = hex_md5(pw);
		return true;
	}
	</SCRIPT>
	
</HEAD>

<BODY>

<H1>U bent niet correct ingelogd</H1>

<? 
//	echo SID;
//	echo "<pre>";
//	print_r($_SESSION);
//	echo "</pre>";
//	if(isset($_POST['reason'])) {
//		echo $_POST['reason']."<BR>";
//	}
?>

<FORM NAME="form" METHOD="post" ACTION="<?= $_SERVER['PHP_SELF'] ?>" onSubmit="preSubmit()">
	<? 
		echo session_input();
//		foreach($_POST as $key => $value) {
//			echo '<INPUT TYPE="hidden" name="'.$key.'" VALUE="'.$value.'">';
//		}
//		foreach($_GET as $key => $value) {
//			echo '<INPUT TYPE="hidden" name="'.$key.'" VALUE="'.$value.'">';
//		}
	?>
	<INPUT TYPE="hidden" NAME="randString" VALUE="<?= $_SESSION['randString'] ?>">
	<TABLE BORDER=0 CELLSPACING=0 CELLPADDING=5>
		<TR>
			<TD> naam </TD>
			<TD> <INPUT TYPE="text" NAME="user"> </TD>
		</TR>
		<TR>
			<TD> wachtwoord </TD>
			<TD> 
				<INPUT TYPE="password" NAME="user_password" VALUE=""> 
				<INPUT TYPE="hidden" NAME="password">
			</TD>
		</TR>
		<TR>
			<TD COLSPAN="2">
				<INPUT TYPE="submit" VALUE="Login"> 
			</TD>
		</TR>
	</TABLE>
</FORM>


</BODY>
</HTML>

