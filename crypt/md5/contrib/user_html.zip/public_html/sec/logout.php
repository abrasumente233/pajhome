<?php
	session_start();
	session_destroy();
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 3.2 Final//EN">
<HTML>
<HEAD>
<TITLE>uitgelogd</TITLE>
<META NAME="Generator" CONTENT="TextPad 4.6">
<META NAME="Author" CONTENT="Friso Vrolijken">
</HEAD>

<BODY>
U bent uitgelogd
</BODY>
</HTML>
